package com.example.prakashr.ecommerecepoc;

/**
 * Created by Prakash.R on 27-12-2017.
 */

public class Listitem {


    private String head;
    private String desc;


    public Listitem(String head, String desc) {
        this.head = head;
        this.desc = desc;
    }

    public String getHead() {
        return head;
    }

    public String getDesc() {
        return desc;
    }
}
